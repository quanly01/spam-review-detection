from django.http import HttpResponse, HttpResponseRedirect
from django.shortcuts import render
from django.contrib.auth.decorators import login_required
from django.urls import reverse
from django.contrib import messages
import decimal
import re
import pandas as pd 
import numpy as np
import pickle
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.naive_bayes import MultinomialNB
import matplotlib.pyplot as plt
import seaborn as sns
from .models import Orders
from sklearn.feature_extraction.text import TfidfVectorizer
from transformers import AutoTokenizer, AutoModelForSequenceClassification, Trainer, TrainingArguments, BertTokenizer, BertForSequenceClassification
import torch
from vncorenlp import VnCoreNLP
import py_vncorenlp

class BuildDataset(torch.utils.data.Dataset):
    def __init__(self, encodings, labels=None):
        self.encodings = encodings
        self.labels = labels

    def __getitem__(self, idx):
        item = {key: torch.tensor(val[idx]) for key, val in self.encodings.items()}
        if self.labels:
            item["labels"] = torch.tensor(self.labels[idx])
        return item

    def __len__(self):
        return len(self.encodings["input_ids"])


vncorenlp = py_vncorenlp.VnCoreNLP(save_dir="D:/Download/VnCoreNLP-master/VnCoreNLP-master", annotators=["wseg"])

with open("D:/Download/vietnamese-stopwords-dash.txt", "r", encoding='UTF8') as ins:
    stopwords = []
    for line in ins:
        dd = line.strip('\n')
        stopwords.append(dd)
    stopwords = set(stopwords)

def filter_stop_words(train_sentences, stop_words):
    new_sent = [word for word in train_sentences.split() if word not in stop_words]
    train_sentences = ' '.join(new_sent)

    return train_sentences


def deEmojify(text):
    regrex_pattern = re.compile(pattern = "["
        u"\U0001F600-\U0001F64F"  # emoticons
        u"\U0001F300-\U0001F5FF"  # symbols & pictographs
        u"\U0001F680-\U0001F6FF"  # transport & map symbols
        u"\U0001F1E0-\U0001F1FF"  # flags (iOS)
                           "]+", flags = re.UNICODE)
    return regrex_pattern.sub(r'',text)


def preprocess(text, tokenized=True, lowercased=True):
    # text = ViTokenizer.tokenize(text)
    # text = ' '.join(vncorenlp.tokenize(text)[0])
    # text = filter_stop_words(text, stopwords)
    # text = deEmojify(text)
    # text = text.lower() if lowercased else text
    # if tokenized:
    #     pre_text = ""
    #     sentences = vncorenlp.word_segment(text)
    #     for sentence in sentences:
    #         pre_text += " ".join(sentence)
    #     text = pre_text
    return text


def pre_process_features(X, y1, y2, tokenized=True, lowercased=True):
    X = np.array(X)
    y1 = np.array(y1)
    y2 = np.array(y2)
    X = [preprocess(str(p), tokenized=tokenized, lowercased=lowercased) for p in list(X)]
    for idx, ele in enumerate(X):
        if not ele:
            np.delete(X, idx)
            np.delete(y1, idx)
            np.delete(y2, idx)
    return X, y1, y2



def mainpage(request):
    return render(request, 'orders/home.html')

def home(request):
    return render(request, 'orders/introduction.html')

def index(request):
    return render(request, "orders/index.html")

def indextwo(request):
    return render(request, "orders/index2.html")

def analysis(request):
    return render(request, "orders/index2.html")

@login_required
def love(request):
    return render(request, "orders/love.html")

@login_required
def sad(request):
    return render(request, "orders/sad.html")



@login_required
def predict(request):
    if request.method == 'GET':
        return HttpResponseRedirect(reverse('index'))

    if request.method == 'POST':
        message = request.POST['msg']
        message_2 = message
        message = str(message)
        model = AutoModelForSequenceClassification.from_pretrained("D:/Download/transformermodel/transformermodel/phobert/task", num_labels = 2)
        tokenizer = AutoTokenizer.from_pretrained("vinai/phobert-base", use_fast=False)
        trainer = Trainer(model=model)
        message = preprocess(message)
        message = list([message])
        message = tokenizer(message, truncation=True, padding=True, max_length=100)
        message = BuildDataset(message)
        raw_pred, _, _ = trainer.predict(message)
        prediction = np.argmax(raw_pred, axis=1)
        if prediction== np.array([0]):
            order = Orders(username = request.user.username, send_message = message_2, status = 'Ham')
            order.save()
            return render(request, "orders/love.html")
        else:
            order = Orders(username = request.user.username, send_message = message_2, status = 'Spam')
            order.save()
            return render(request, "orders/sad.html")
    
@login_required
def predict_four_label(request):
    if request.method == 'GET':
        return HttpResponseRedirect(reverse('index'))

    if request.method == 'POST':
        message = request.POST['msg']
        message_2 = message
        message = str(message)
        model = AutoModelForSequenceClassification.from_pretrained("D:/Download/transformers_four_label", num_labels = 4)
        tokenizer = AutoTokenizer.from_pretrained("vinai/phobert-base", use_fast=False)
        trainer = Trainer(model=model)
        message = preprocess(message)
        message = list([message])
        message = tokenizer(message, truncation=True, padding=True, max_length=100)
        message = BuildDataset(message)
        raw_pred, _, _ = trainer.predict(message)
        prediction = np.argmax(raw_pred, axis=1)
        if prediction== np.array([0]):
            order = Orders(username = request.user.username, send_message = message_2, status = 'Ham')
            order.save()
            return render(request, "orders/love.html")
        if prediction== np.array([1]):
            order = Orders(username = request.user.username, send_message = message_2, status = 'Fake Review')
            order.save()
            return render(request, "orders/sad1.html")
        if prediction== np.array([2]):
            order = Orders(username = request.user.username, send_message = message_2, status = 'Review On Brand Only')
            order.save()
            return render(request, "orders/sad2.html")
        if prediction== np.array([3]):
            order = Orders(username = request.user.username, send_message = message_2, status = 'Non-Review')
            order.save()
            return render(request, "orders/sad3.html")
    

