# spam_detection

Our project consists of several comprehensive steps: 

Starting from data pre-processing  

Comparing the effectiveness of various machine learning algorithms to choose the most efficient model. 

Our goal is to select a model that can accurately distinguish between spam and ham messages, and then embed this model into a user-friendly website. With our website, 
users will be able to easily and reliably determine whether a message is spam or not. 

